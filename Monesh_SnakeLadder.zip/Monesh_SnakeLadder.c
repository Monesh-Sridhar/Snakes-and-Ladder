// code is for Snakes And Ladders Game In C LanguageC
#include<stdio.h>
#include<stdlib.h>

int player1Position=0 ,player2Position = 0;


// defining the structure of the linked list
struct node{
    int position, dice;
    struct node *next;
}*player1,*player1_lastpos, *player2,*player2_lastpos;


// logic to add a node to player1
void addplayer1Node(int pos,int dice){
    
    
    struct node *temp;
    temp = (struct node *) malloc(sizeof(struct node));
    temp->position = pos;
    temp->dice = dice;
    temp->next = NULL;
    
    if (player1==NULL){
        player1 = temp;
        player1_lastpos = temp;
    }
    else{
        player1_lastpos->next = temp;
        player1_lastpos = temp;
    }

}
// logic to add a node to player2
void addplayer2Node(int pos,int dice){
    
    
    struct node *temp;
    temp = (struct node *) malloc(sizeof(struct node));
    temp->position = pos;
    temp->dice = dice;
    temp->next = NULL;
    
    if (player2==NULL){
        player2 = temp;
        player2_lastpos = temp;
    }
    else{
        player2_lastpos->next = temp;
        player2_lastpos = temp;
    }

}

// To print all the movements made by the player
void printMovements(struct node *root){
    
    struct node * temp = root;
    
    while(temp!=NULL){
        printf("Position : %d Dice: %d\n",temp->position,temp->dice);
        temp=temp->next;
    }
}

// To get the length of the linked list
int getLength(struct node *root){
    
    struct node *temp;
    
    temp = root;
    
    int count=0;
    while(temp!=NULL){
        count++;
        temp = temp->next;
    }
    return count;
}

// Get a random dice value
int randomDice()
{
    int rem;
    while(1){
        rem=rand()%7;
        if(rem!=0){
            return rem;
        }
    }
}

// Get random position on the board
int randomBoardPosition(int finalPosition){
    int rem;
    while(1){
        rem =rand()%finalPosition;
        if(rem!=0){
            return rem;
        }
    }
}

// Get random value between 1 and 10
int randomValue(){
    int rem;
    while(1){
        // The snake and the ladder, the alter the position of the player either from 1 to 10
        // So generating a random number between 1 to 10
        rem = rand()% 11;
        if(rem!=0){
            return rem;
        }
    }
}


// Print the current position of both the players
void getPlayerPosition(){
    printf("*********************\n");
    printf("Player Positions\n");
    printf("\t Player 1 : %d\n",player1_lastpos->position);
    printf("\t Player 2 : %d\n",player2_lastpos->position);
    printf("*********************\n\n");
}

int main(){
    
    int dvalue;
    int playerFlag=0,flag=0;
    
    // generate a random grid size between 32 and 64
    int finalPosition = (rand() % (64-32+1)) + 32;
    printf("Number of Grids : %d\n",finalPosition);
    
    // Setting inital position of players
    addplayer1Node(0,0);
    addplayer2Node(0,0);
    
        
    // varaibales to define the postion of the snakes and the ladders 
    // The index of corresponding array will be denoting the location of the snake head or the ladders bottom
    // The values of the varibales will be set to 0 when there is not snake or ladder in that Position
    int snakes[finalPosition];
    int ladders[finalPosition];
    
    int numSnakes=2;
    int numLadders=2;
    
    
    printf("Enter the number of snakes on the board  : ");
    scanf("%d",&numSnakes);
    printf("Enter the number of ladders on the board : ");
    scanf("%d",&numLadders);
    
    printf("Snake & Ladder Game\n");
    printf("\t\tStarting Position : 1\n");
    printf("\t\tEnding Position   : %d\n\n",finalPosition);
    
    
    // initalize the variables to zero
    for (int i=0;i<finalPosition;i++){
        snakes[i]=0;
        ladders[i]=0;
    }
    
    // Setting up ladders in the board environment
    printf("Ladder Positions: \n");
    for(int i=0;i<numLadders;){
        int ladderBottom = randomBoardPosition(finalPosition);
        int ladderLength = randomValue();
        // The ladder is valid only when it can be placed within the board
        if(ladderBottom + ladderLength < finalPosition){
            ladders[ladderBottom-1] = ladderBottom+ladderLength;
            i++;
            
            printf("\tLadder %d :  %d -> %d\n",i,ladderBottom, ladderBottom+ladderLength);
        }
    }
    
    // Setting up snakes in the board environment
    printf("Snake Positions: \n");
    for(int i=0;i<numSnakes;){
        int snakeHead = randomBoardPosition(finalPosition);
        int snakeLength = randomValue();
        // The snake is valid only when it can be placed within the board
        if(snakeHead - snakeLength  > 0){
            snakes[snakeHead-1] = snakeHead-snakeLength;
            i++;
            printf("\tSnake %d :  %d -> %d\n",i,snakeHead, snakeHead-snakeLength);
        }
    }
    
    
    printf("\n Initial Position Before Game Starts\n");
    getPlayerPosition();
    
    printf("Game Starts \n");
    
    while( player2Position != finalPosition || player1Position != finalPosition ){
        dvalue = randomDice();
        flag=0;
        
        // Updating the position of the corresponsing player as per the random Dice value
        if(playerFlag==0){
            // update player 1 position if its not crossing the finalPosition
            printf("Player 1 rolled %d \n",dvalue);
            if(player1Position+dvalue <= finalPosition){
                player1Position+=dvalue;
            }else{
                printf("Player 1 unable to move\n");
            }
        }
        else{
            //update player 2 position if its not crossing the finalPosition
            printf("Player 2 rolled %d \n",dvalue);
            if(player2Position+dvalue <= finalPosition){
                player2Position+=dvalue;
            }
            else{
                printf("Player 2 unable to move\n");
            }
        }
        
        
        // The snake always has the highest Priority than the ladder
        // check if the player encounters a snake
        if(playerFlag==0){
            // player 1
            if(snakes[player1Position-1]!=0){
                // The snake is present
                
                printf("Player 1 encounter snake at %d moved to %d\n",player1Position,snakes[player1Position-1]);
                player1Position = snakes[player1Position-1];
                flag=1;
            }
        }
        else{
            //player 2
            if(snakes[player2Position-1]!=0){
                // The snake is present
                printf("Player 2 encounter snake at %d moved to %d\n",player2Position,snakes[player2Position-1]);
                player2Position=snakes[player2Position-1];
                flag=1;
            }
        }
        
       
        // check if the player encounters a ladder
        // The player cannot use the ladder if he came down by encountering a snake
        if(flag!=1){
            if(playerFlag==0){
                //player 1
                if(ladders[player1Position-1]!=0){
                    // Ladder is present
                    printf("Player 1 encounter ladder at %d moved to %d\n",player1Position,ladders[player1Position-1]);
                    player1Position= ladders[player1Position-1];
                
                }
            }
            else{
                //player 2 
                if(ladders[player2Position-1]!=0){
                    // Ladder is present
                    printf("Player 2 encounter ladder at %d moved to %d\n",player2Position,ladders[player2Position-1]);
                    player2Position= ladders[player2Position-1];
                    
                }
                
            }
        }
        
        // Adding the position and dice value of the player to the linked list
        if(playerFlag==0){
                addplayer1Node(player1Position,dvalue);
            }
            else{
                addplayer2Node(player2Position,dvalue);
            }
        
        
        
         // If the dice value is either 1 ,5,6  The same player plays the next turn
        // But this is not applicable when the player encounters a snake
        if( (dvalue!=1 && dvalue!=5 && dvalue!=6) && flag!=1){
            if(playerFlag==0){
                playerFlag=1;
            }
            else{
                playerFlag=0;
            }
        }else{
            if(playerFlag==0){
                printf("Player 1 keeps his turn\n");
            }else{
                printf("Player 2 keeps his turn\n");
            }
        }
        
        
        // Printing the new Position of the Player
        getPlayerPosition();
        if (player1Position == finalPosition){
            printf("Player 1 Won the Game");
            break;
        }
        else if (player2Position == finalPosition){
            printf("Player 2 Won the Game");
            break;
            
        }
        
       
        
    }
    printf("\n-----------------------------------\n");
    printf("Number of movements by Player 1 :%d\n",getLength(player1));
    printf("Player 1 Movements:\n");
    printMovements(player1);
    
    printf("\n-----------------------------------\n");    
    printf("Number of movements by Player 2 :%d\n",getLength(player2));
    printf("Player 2 Movements:\n");
    printMovements(player2);
    
    
    
    
}